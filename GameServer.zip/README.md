Set Multiple startup projects: GameServer.Api & GameServer.Client
Optiona: Configure port from :8080 to any other (on server and client side)