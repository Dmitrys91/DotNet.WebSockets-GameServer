﻿namespace GameServer.Common.Contracts
{
    public class LoginResponse
    {
        public int PlayerId { get; set; }
    }
}
