﻿using GameServer.Domain;

namespace GameServer.Common.Contracts
{
    public class SendGiftResponse
    {
      
    }
}
