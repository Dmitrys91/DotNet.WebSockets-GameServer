﻿namespace GameServer.Common.Contracts
{ 
    public class LoginRequest
    {
        public Guid DeviceId { get; set; }
    }
}
